# AlphaZero Gomoku
A multi-threaded implementation of AlphaZero

## Features
* Free-style Gomoku
* Tree/Root Parallelization with Virtual Loss/LibTorch
* Gomoku and MCTS are written in C++
* Support Ubuntu and Windows

# 正在逐步研发中。。。。。。
